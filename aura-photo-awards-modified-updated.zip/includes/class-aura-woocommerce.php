<?php
class AURA_WooCommerce {
    public function __construct() {
        error_log('AURA WooCommerce class initialized');
        add_action('woocommerce_order_status_completed', array($this, 'process_credit_purchase'));
        add_action('woocommerce_payment_complete', array($this, 'process_credit_purchase'));
    }

    private function get_product_credits($product) {
        // Versuche zuerst, Credits aus den Produktattributen zu holen
        $attributes = $product->get_attributes();
        if (isset($attributes['credits']) && is_numeric($attributes['credits'])) {
            return (int)$attributes['credits'];
        }

        // Fallback auf Meta-Daten
        $credits = get_post_meta($product->get_id(), '_aura_credits', true);
        if (is_numeric($credits)) {
            return (int)$credits;
        }

        return 0; // Keine Credits gefunden
    }

    public function process_credit_purchase($order_id) {
    error_log('AURA: WooCommerce order processing started for order ID: ' . $order_id);

    $order = wc_get_order($order_id);

    if (empty($order)) {
        error_log('AURA: Order not found!');
        return;
    }

    $user_id = $order->get_user_id();
    if (!$user_id) {
        error_log('AURA: No user associated with this order!');
        return;
    }

    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        $credits_to_add = get_post_meta($product->get_id(), '_aura_credits', true);

        if ($credits_to_add) {
            $current_credits = aura_get_user_credits($user_id);
            $new_total = $current_credits + $credits_to_add;

            update_user_meta($user_id, 'aura_credits', $new_total);

            error_log('AURA: Updated credits for user ' . $user_id . ': ' . $new_total);
        } else {
            error_log('AURA: No credits assigned to product ID: ' . $product->get_id());
        }
    }
}

}