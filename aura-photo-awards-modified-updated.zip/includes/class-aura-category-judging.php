<?php

class AURA_Category_Judging {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('wp_ajax_aura_load_thumbnails', [__CLASS__, 'load_thumbnails']);
        add_action('wp_ajax_aura_save_category_judging', [__CLASS__, 'handle_category_judging_save']);
        add_action('wp_ajax_aura_assign_category_badges', [__CLASS__, 'assign_category_badges']);
    }

    public static function register_menu() {
        add_submenu_page(
            'aura-photo-awards',
            __('Category Judging', 'aura-photo-awards'),
            __('Category Judging', 'aura-photo-awards'),
            'manage_options',
            'aura-category-judging',
            [__CLASS__, 'render_category_judging_page']
        );
    }

    public static function enqueue_assets($hook) {
        if ($hook !== 'aura-photo-awards_page_aura-category-judging') {
            return;
        }

        wp_enqueue_style('aura-category-judging', AURA_PLUGIN_URL . 'assets/css/category-judging.css', [], AURA_VERSION);
        wp_enqueue_script('aura-category-judging', AURA_PLUGIN_URL . 'assets/js/category-judging.js', ['jquery'], AURA_VERSION, true);

        wp_localize_script('aura-category-judging', 'auraCategoryJudging', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aura_category_judging_nonce'),
        ]);
    }

    public static function render_category_judging_page() {
        ?>
        <div class="wrap aura-category-judging-dashboard">
            <div class="aura-category-thumbnails">
                <h3><?php _e('Submissions', 'aura-photo-awards'); ?></h3>
                <div id="thumbnail-list"></div>
            </div>
            <div class="aura-category-main">
                <h3><?php _e('Selected Photo', 'aura-photo-awards'); ?></h3>
                <div id="selected-photo"></div>
                <div id="photo-details"></div>
            </div>
            <div class="aura-category-controls">
                <h3><?php _e('Judging Panel', 'aura-photo-awards'); ?></h3>
                <div id="rating-panel">
                    <?php
                    $criteria = ['Overall', 'Technical Aspects', 'Color Grading'];
                    foreach ($criteria as $criterion) {
                        echo '<div class="rating-stars" data-criterion="' . esc_attr($criterion) . '">';
                        echo '<label>' . esc_html($criterion) . ':</label>';
                        for ($i = 1; $i <= 5; $i++) {
                            echo '<span class="rating-star" data-value="' . $i . '">☆</span>';
                        }
                        echo '</div>';
                    }
                    ?>
                </div>
                <button id="judge-save" class="button button-primary"><?php _e('Save Judging', 'aura-photo-awards'); ?></button>
                <button id="assign-badges" class="button button-secondary"><?php _e('Assign Badges', 'aura-photo-awards'); ?></button>
            </div>
        </div>
        <?php
    }

    public static function load_thumbnails() {
    check_ajax_referer('aura_category_judging_nonce', 'nonce');

    $args = [
        'post_type' => 'photo_submission',
        'posts_per_page' => -1,
        'post_status' => 'reviewed',
        'meta_query' => [
            [
                'key' => '_aura_jury_points',
                'value' => 95,
                'compare' => '>=',
                'type' => 'NUMERIC'
            ]
        ]
    ];

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        $thumbnails = [];
        while ($query->have_posts()) {
            $query->the_post();
            $thumbnails[] = [
    'id' => get_the_ID(),
    'title' => get_the_title(),
    'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
    'fullsize' => get_the_post_thumbnail_url(get_the_ID(), 'full') // Originalbild-URL
];
error_log(print_r($thumbnails, true));
        }
        wp_send_json_success($thumbnails);
    } else {
        wp_send_json_success([]); // Keine Bilder gefunden
    }
    wp_reset_postdata();
}


    public static function handle_category_judging_save() {
        check_ajax_referer('aura_category_judging_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to perform this action.', 'aura-photo-awards'));
        }

        $post_id = intval($_POST['post_id']);
        $ratings = isset($_POST['ratings']) ? $_POST['ratings'] : [];

        if (!$post_id || get_post_type($post_id) !== 'photo_submission') {
            wp_send_json_error(__('Invalid photo submission.', 'aura-photo-awards'));
        }

        $category_points = 0;
        foreach ($ratings as $criterion => $value) {
            if (!in_array($criterion, ['Overall', 'Technical Aspects', 'Color Grading']) || !is_numeric($value) || $value < 1 || $value > 5) {
                wp_send_json_error(__('Invalid rating value.', 'aura-photo-awards'));
            }
            $category_points += intval($value);
            update_post_meta($post_id, "_aura_category_rating_{$criterion}", intval($value));
        }

        update_post_meta($post_id, '_aura_category_points', $category_points);

        wp_send_json_success([
            'message' => __('Category judging saved successfully.', 'aura-photo-awards'),
            'category_points' => $category_points
        ]);
    }

    public static function assign_category_badges() {
        check_ajax_referer('aura_category_judging_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to perform this action.', 'aura-photo-awards'));
        }

        $badges = ['1-placed-badge.png', '2-placed-badge.png', '3-placed-badge.png'];
        $positions = ['top-left', 'top-right', 'bottom-right'];

        global $wpdb;
        $results = $wpdb->get_results("
            SELECT p.ID
            FROM {$wpdb->posts} AS p
            JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id AND pm.meta_key = '_aura_category_points'
            WHERE p.post_status = 'reviewed'
            ORDER BY pm.meta_value DESC
            LIMIT 3
        ", ARRAY_A);

        foreach ($results as $index => $result) {
            $badge_path = AURA_BADGES_PATH . $badges[$index];
            $post_id = $result['ID'];

            $original_path = get_attached_file(get_post_thumbnail_id($post_id));
            $badged_image = self::apply_badge($original_path, $badge_path, $positions[$index]);

            $upload_dir = wp_upload_dir();
            $badged_filename = 'badged-' . basename($original_path);
            $badged_path = $upload_dir['path'] . '/' . $badged_filename;

            imagepng($badged_image, $badged_path);
            imagedestroy($badged_image);

            $attachment = [
                'post_mime_type' => 'image/png',
                'post_title' => 'Badged ' . get_the_title($post_id),
                'post_content' => '',
                'post_status' => 'inherit'
            ];

            $attach_id = wp_insert_attachment($attachment, $badged_path, $post_id);
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_data = wp_generate_attachment_metadata($attach_id, $badged_path);
            wp_update_attachment_metadata($attach_id, $attach_data);

            update_post_meta($post_id, '_category_badge_image_id', $attach_id);
        }

        wp_send_json_success(__('Badges assigned successfully.', 'aura-photo-awards'));
    }

    private static function apply_badge($image_path, $badge_path, $position) {
        if (!file_exists($image_path) || !file_exists($badge_path)) {
            return false;
        }

        $image = imagecreatefromstring(file_get_contents($image_path));
        $badge = imagecreatefrompng($badge_path);

        $img_width = imagesx($image);
        $img_height = imagesy($image);
        $badge_width = imagesx($badge);
        $badge_height = imagesy($badge);

        $positions = [
            'top-left' => [20, 20],
            'top-right' => [$img_width - $badge_width - 20, 20],
            'bottom-left' => [20, $img_height - $badge_height - 20],
            'bottom-right' => [$img_width - $badge_width - 20, $img_height - $badge_height - 20],
        ];

        $coords = $positions[$position] ?? [20, 20];

        imagealphablending($image, true);
        imagesavealpha($image, true);
        imagecopy($image, $badge, $coords[0], $coords[1], 0, 0, $badge_width, $badge_height);

        imagedestroy($badge);

        return $image;
    }
}

AURA_Category_Judging::init();
