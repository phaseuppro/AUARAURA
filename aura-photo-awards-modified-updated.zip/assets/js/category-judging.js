jQuery(document).ready(function ($) {
    let currentPhotoId = null;

    function calculateCategoryPoints() {
        let totalStars = 0;
        $('.rating-stars').each(function () {
            const stars = $(this).find('.active').length;
            totalStars += stars;
        });

        $('#category-points').text(`Category Points: ${totalStars}`);
    }

    function loadThumbnails() {
        $.ajax({
            url: auraCategoryJudging.ajaxurl,
            method: 'POST',
            data: {
                action: 'aura_load_thumbnails',
                nonce: auraCategoryJudging.nonce
            },
            success: function (response) {
                if (response.success) {
                    const thumbnailList = $('#thumbnail-list');
                    thumbnailList.empty();
                    response.data.forEach(function (thumb) {
                        thumbnailList.append(`
                            <img src="${thumb.thumbnail}" 
                                 class="thumbnail" 
                                 data-id="${thumb.id}" 
                                 data-fullsize="${thumb.fullsize}" 
                                 title="${thumb.title}" />
                        `);
                    });
                } else {
                    alert('No thumbnails available.');
                }
            },
            error: function () {
                alert('Failed to load thumbnails.');
            }
        });
    }

    $('#thumbnail-list').on('click', '.thumbnail', function () {
        // Markiere das ausgewählte Thumbnail
        $('.thumbnail').removeClass('active');
        $(this).addClass('active');

        // Hole die Originalbild-URL
        const fullsizeSrc = $(this).data('fullsize');
        const title = $(this).attr('title');
        currentPhotoId = $(this).data('id');

        // Zeige das Originalbild in der Mitte
        if (fullsizeSrc) {
            $('#selected-photo').html(`
                <img src="${fullsizeSrc}" class="full-size-image" alt="${title}" />
            `);
        } else {
            alert('Failed to load the full-size image.');
        }

        console.log('Selected image source:', fullsizeSrc);
    });

    $('.rating-stars').on('click', 'span', function () {
        $(this)
            .siblings()
            .removeClass('active')
            .end()
            .prevAll()
            .addBack()
            .addClass('active');

        calculateCategoryPoints();
    });

    $('#judge-save').on('click', function () {
        if (!currentPhotoId) {
            alert('Please select a photo to judge.');
            return;
        }

        const ratings = {};
        $('.rating-stars').each(function () {
            ratings[$(this).data('criterion')] = $(this).find('.active').length || 0;
        });

        $.ajax({
            url: auraCategoryJudging.ajaxurl,
            method: 'POST',
            data: {
                action: 'aura_save_category_judging',
                nonce: auraCategoryJudging.nonce,
                post_id: currentPhotoId,
                ratings: ratings
            },
            success: function (response) {
                if (response.success) {
                    alert('Judgment saved successfully.');
                } else {
                    alert(response.data || 'Failed to save judgment.');
                }
            },
            error: function () {
                alert('An error occurred while saving the judgment.');
            }
        });
    });

    $('#assign-badges').on('click', function () {
        const category = $('#category-filter').val();

        $.ajax({
            url: auraCategoryJudging.ajaxurl,
            method: 'POST',
            data: {
                action: 'aura_assign_category_badges',
                nonce: auraCategoryJudging.nonce,
                category: category
            },
            success: function (response) {
                if (response.success) {
                    alert('Badges assigned successfully.');
                } else {
                    alert(response.data || 'Failed to assign badges.');
                }
            },
            error: function () {
                alert('An error occurred while assigning badges.');
            }
        });
    });

    loadThumbnails();
});
